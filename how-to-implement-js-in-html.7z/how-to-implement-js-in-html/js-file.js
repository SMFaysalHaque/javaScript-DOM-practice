console.log(100);
console.log(document); //here document is an object where our whole website stable.
// console.log(document.body); // this a part of an object.


// document.getElementsByTagName('h3'); it's only run on browser.
// document.getElementsByTagName('article'); it's only run on browser.

// if we want to show these tags from our .js file we have to do bellow task:

const blogsTitle = document.getElementsByTagName('h3');
// console.log(blogsTitle);

//we can use "for loop" or "for of loop"
for(let i = 0; i < blogsTitle.length; i++){
    // console.log(h3);
    console.log(i.innerText); 
}
// for(const h3 of blogsTitle){
//     console.log(h3);
//     console.log(h3.innerText);
// } 